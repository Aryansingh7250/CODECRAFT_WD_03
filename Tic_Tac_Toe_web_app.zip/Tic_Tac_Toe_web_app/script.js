class TicTacToe {
    constructor() {
        this.board = Array(9).fill(null);
        this.currentPlayer = 'X';
        this.gameActive = true;
        this.winningCombinations = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
            [0, 4, 8], [2, 4, 6]             // Diagonals
        ];
        this.matchNumber = 1;
        this.maxMatches = 10;
        this.teamXWins = 0;
        this.teamOWins = 0;
        this.matchHistory = [];
        this.teamXName = 'Team X';
        this.teamOName = 'Team O';
        this.initializeGame();
    }

    initializeGame() {
        // Initialize team names
        this.teamXName = document.getElementById('teamX').value;
        this.teamOName = document.getElementById('teamO').value;
        
        // Add event listeners for team name changes
        document.getElementById('teamX').addEventListener('input', (e) => {
            this.teamXName = e.target.value;
            this.updateStatus();
        });
        document.getElementById('teamO').addEventListener('input', (e) => {
            this.teamOName = e.target.value;
            this.updateStatus();
        });

        const cells = document.querySelectorAll('.cell');
        cells.forEach(cell => {
            cell.addEventListener('click', () => this.handleCellClick(cell));
        });

        document.getElementById('reset-button').addEventListener('click', () => this.resetGame());
        this.updateScoreboard();
        this.updateMatchNumber();
        this.updateStatus();
    }

    handleCellClick(cell) {
        if (this.gameActive && cell.textContent === '') {
            const cellIndex = cell.getAttribute('data-cell-index');
            this.board[cellIndex] = this.currentPlayer;
            cell.textContent = this.currentPlayer;
            
            if (this.checkWinner()) {
                this.gameActive = false;
                this.recordMatch(this.currentPlayer);
                this.updateStatus(`${this.getCurrentTeamName()} wins!`);
            } else if (this.isBoardFull()) {
                this.gameActive = false;
                this.recordMatch('Draw');
                this.updateStatus('Game Draw!');
            } else {
                this.currentPlayer = this.currentPlayer === 'X' ? 'O' : 'X';
                this.updateStatus();
            }
        }
    }

    checkWinner() {
        return this.winningCombinations.some(combination => {
            return combination.every(index => {
                return this.board[index] === this.currentPlayer;
            });
        });
    }

    isBoardFull() {
        return this.board.every(cell => cell !== null);
    }

    getCurrentTeamName() {
        return this.currentPlayer === 'X' ? this.teamXName : this.teamOName;
    }

    recordMatch(result) {
        const matchResult = {
            number: this.matchNumber,
            result: result,
            winner: result === 'Draw' ? 'Draw' : this.getCurrentTeamName(),
            teamX: this.teamXName,
            teamO: this.teamOName
        };
        this.matchHistory.push(matchResult);
        this.updateMatchHistory();

        if (result === 'X') {
            this.teamXWins++;
        } else if (result === 'O') {
            this.teamOWins++;
        }

        // Check if series is over
        if (this.teamXWins >= 6 || this.teamOWins >= 6 || this.matchNumber >= this.maxMatches) {
            this.gameActive = false;
            this.updateStatus(this.getSeriesWinner());
            return;
        }

        // Start next match
        this.matchNumber++;
        this.resetGame();
    }

    getSeriesWinner() {
        if (this.teamXWins >= 6) {
            return `${this.teamXName} wins the series with ${this.teamXWins} wins!`;
        } else if (this.teamOWins >= 6) {
            return `${this.teamOName} wins the series with ${this.teamOWins} wins!`;
        } else {
            return `Series ends in ${this.teamXWins}-${this.teamOWins} after ${this.maxMatches} matches!`;
        }
    }

    updateScoreboard() {
        document.getElementById('scoreX').textContent = `${this.teamXName} Wins: ${this.teamXWins}`;
        document.getElementById('scoreO').textContent = `${this.teamOName} Wins: ${this.teamOWins}`;
    }

    updateMatchNumber() {
        document.querySelector('.match-number span').textContent = `Match: ${this.matchNumber}/${this.maxMatches}`;
    }

    updateMatchHistory() {
        const historyList = document.getElementById('history-list');
        historyList.innerHTML = '';
        this.matchHistory.forEach(match => {
            const item = document.createElement('div');
            item.className = 'history-item';
            item.innerHTML = `
                <span>Match ${match.number}</span>
                <span>${match.winner}</span>
            `;
            historyList.appendChild(item);
        });
    }

    resetGame() {
        this.board = Array(9).fill(null);
        this.currentPlayer = 'X';
        this.gameActive = true;
        
        const cells = document.querySelectorAll('.cell');
        cells.forEach(cell => cell.textContent = '');
        this.updateStatus();
    }

    updateStatus(message = `${this.getCurrentTeamName()}'s turn`) {
        document.querySelector('.status-message').textContent = message;
    }
}

// Initialize the game when the page loads
window.addEventListener('load', () => {
    new TicTacToe();
});
