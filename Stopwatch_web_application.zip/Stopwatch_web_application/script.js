let startTime = 0;
let elapsedTime = 0;
let timerInterval = null;
let lapCount = 0;

const hoursElement = document.getElementById('hours');
const minutesElement = document.getElementById('minutes');
const secondsElement = document.getElementById('seconds');
const millisecondsElement = document.getElementById('milliseconds');
const lapTimesElement = document.getElementById('lap-times');

// Initialize timer display to 0
function initializeTimer() {
    hoursElement.textContent = '00';
    minutesElement.textContent = '00';
    secondsElement.textContent = '00';
    millisecondsElement.textContent = '00';
}

// Initialize the timer when the page loads
initializeTimer();

function formatTime(time) {
    return time.toString().padStart(2, '0');
}

function updateTimer() {
    elapsedTime = Date.now() - startTime;
    
    const hours = Math.floor(elapsedTime / (1000 * 60 * 60));
    const minutes = Math.floor((elapsedTime % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((elapsedTime % (1000 * 60)) / 1000);
    const milliseconds = Math.floor((elapsedTime % 1000) / 10);

    hoursElement.textContent = formatTime(hours);
    minutesElement.textContent = formatTime(minutes);
    secondsElement.textContent = formatTime(seconds);
    millisecondsElement.textContent = formatTime(milliseconds);
}

function startTimer() {
    if (timerInterval) return;
    
    startTime = Date.now() - elapsedTime;
    timerInterval = setInterval(updateTimer, 10);
}

function stopTimer() {
    clearInterval(timerInterval);
    timerInterval = null;
}

function resetTimer() {
    stopTimer();
    elapsedTime = 0;
    startTime = 0;
    initializeTimer();
    lapTimesElement.innerHTML = '';
    lapCount = 0;
}

function addLap() {
    if (!timerInterval) return;
    
    const lapTime = document.createElement('li');
    lapCount++;
    lapTime.textContent = `Lap ${lapCount}: ${hoursElement.textContent}:${minutesElement.textContent}:${secondsElement.textContent}:${millisecondsElement.textContent}`;
    lapTimesElement.insertBefore(lapTime, lapTimesElement.firstChild);
}

// Event listeners
document.getElementById('start').addEventListener('click', startTimer);
document.getElementById('stop').addEventListener('click', stopTimer);
document.getElementById('reset').addEventListener('click', resetTimer);
document.getElementById('lap').addEventListener('click', addLap);
